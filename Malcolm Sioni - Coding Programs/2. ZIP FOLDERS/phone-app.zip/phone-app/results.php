<?php

	//connect to db


	//execute an SQL query


	//loop through matching rows and build an output string


	//print out the output string
	print('yah');

?>