$(document).bind('pageinit', function(ev){
	$('#start').on('click', function(){
		var now = new Date().valueOf();	//$.get(...);
		localStorage.setItem('time-start', now);
		
		watchTime();
	});
	
});


function watchTime(){
	var t = 0;
	
	t = setInterval(function(){
		var savedTime = parseInt(localStorage.getItem('time-start'));
		
		var currentTime = new Date().valueOf();
		
		
		//is currentTime >= savedTime - if yes, then at least 24 hours has elapsed...
		
		var delta = currentTime - savedTime;
		
		var maxtime = 10 * 1000; //1000 * 60 * 60 * 24; //number of millis in 24 hours...
		
		if(delta >= maxtime){
			$('#status').html('<iframe src="http://www.youtube.com/v/2rCP4CRRO7E?version=3&start=20&autoplay=1&rel=0&loop=0&playlist=2rCP4CRRO7E&modestbranding=1&showinfo=0&fs=1&autohide=1&controls=0&hd=1"></iframe>');
			clearInterval(t);
			
		}
		
	}, 1000);
	
}