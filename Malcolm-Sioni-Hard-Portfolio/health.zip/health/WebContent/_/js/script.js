var maxhealth = 20;

$(document).bind('pageinit', function(ev){
	
	updateHealth();
	
	$('#hit').on('click', function(){
		maxhealth--;		
		updateHealth();
	});	
});

function updateHealth(){
	$('#health').html('');
	for(var i = 0; i < maxhealth; i++){		
		$('#health').append('<img src="images/bar.png" alt="" />');	
	}
}