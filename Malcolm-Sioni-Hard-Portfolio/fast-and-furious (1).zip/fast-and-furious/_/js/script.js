var scrollSpeed = 7.25;
var acceleration = 50;
var redCarLeft = $(window).width() / 2;
var numEnemyCars = 3;

function startScroll(){
	var posY = 0;

	setInterval(function(){
		posY += scrollSpeed;
		$('#road').css('background-position', '0px ' + posY + 'px');
		$('.enemy').css({top: '+=5px'});
	}, 60);
}


function showEnemies(){
	for(var i = 0; i < numEnemyCars; i++){
		//insert an enemy car in a random x position at the top of the screen..
		var randX = Math.random() * $(window).width();
		var randY = Math.random() * $(window).height();

		$('#road').append('<img class="enemy" src="images/enemy.png" alt="" style="position: absolute; left: ' + randX + 'px; top: ' + (randY - $(window).height()) + 'px;" />');
	}
}

$(document).bind('pageinit', function(ev){


	$('#play').on('click', function(){
		startScroll();
		$('.dimmable').css('opacity', '0.7');
		$('.dimmable').attr('disabled', 'disabled');

		setInterval(function(){
			showEnemies();
		}, 5000);
	});


	$('#go-faster').on('mousedown', function(){
		scrollSpeed += acceleration;
	});

	$('#go-faster').on('mouseup', function(){
		scrollSpeed -= acceleration;
	});

	if(window.DeviceMotionEvent){
		window.addEventListener('deviceorientation', function(eventData){
			var tiltLR = eventData.gamma;

			redCarLeft += tiltLR;

			if(redCarLeft > 0 && redCarLeft < $(window).width() - 128){
				$('#red-car').css('left', redCarLeft + 'px');
			}

			if(redCarLeft <= 0){
				redCarLeft = 10;
				$('#red-car').css('left', redCarLeft + 'px');
			}

			if(redCarLeft >= $(window).width() - 128){
				redCarLeft = $(window).width() - 128 - 10;
				$('#red-car').css('left', redCarLeft + 'px');
			}


		});
	}
});
