$(document).bind('pageinit', function(ev){

});

$(document).bind('pageshow', function(ev){

});